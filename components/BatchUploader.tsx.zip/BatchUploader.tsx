"use client";

import React, { useMemo, useRef, useState } from "react";

type ApiTop1 = { label: string; index: number; prob: number };
type ApiPrediction = { label: string; prob: number };
type ApiResponse = {
  predictions: ApiPrediction[];
  top1: ApiTop1;
  probs: number[];
  labels_current: string[];
};

type Job = {
  id: string;
  file: File;
  name: string;
  status: "queued" | "running" | "done" | "error" | "canceled";
  startedAt?: number;
  finishedAt?: number;
  ms?: number;
  result?: ApiResponse;
  error?: string;
  preview?: string;
};

function fmtMs(ms?: number) {
  if (ms === undefined) return "-";
  if (ms < 1000) return `${ms} ms`;
  return `${(ms / 1000).toFixed(2)} s`;
}

function toCSV(rows: Array<Record<string, any>>) {
  if (!rows.length) return "";
  const headers = Object.keys(rows[0]);
  const esc = (v:any) => `"${String(v ?? "").replace(/"/g, '""')}"`;
  return [headers.map(esc).join(","), ...rows.map(r => headers.map(h => esc(r[h])).join(","))].join("\n");
}

async function predictOne(apiUrl: string, file: File, signal?: AbortSignal): Promise<ApiResponse> {
  const fd = new FormData();
  fd.append("file", file, file.name);
  const res = await fetch(apiUrl, { method: "POST", body: fd, signal });
  if (!res.ok) {
    const text = await res.text().catch(() => "");
    throw new Error(`HTTP ${res.status} ${res.statusText} - ${text.slice(0,200)}`);
  }
  return res.json();
}

export default function BatchUploader() {
  // 🔒 ล็อก API URL จาก env (หรือจะใส่เป็น string ตรงนี้ก็ได้)
  const apiUrl = process.env.NEXT_PUBLIC_API_URL || "https://8bd8fafd5f85.ngrok-free.app/predict";

  const [concurrency, setConcurrency] = useState<number>(3);
  const [jobs, setJobs] = useState<Job[]>([]);
  const [isRunning, setIsRunning] = useState(false);
  const [filter, setFilter] = useState<"all"|"queued"|"running"|"done"|"error">("all");
  const abortRef = useRef<AbortController | null>(null);

  const onPickFiles = (files: FileList | null) => {
    if (!files) return;
    const list: Job[] = Array.from(files).map((f, i) => ({
      id: `${Date.now()}_${i}_${f.name}`,
      file: f,
      name: f.name,
      status: "queued",
    }));
    // preview
    list.forEach((j) => {
      const reader = new FileReader();
      reader.onload = () => setJobs(prev => prev.map(p => p.id===j.id ? { ...p, preview: String(reader.result) } : p));
      reader.readAsDataURL(j.file);
    });
    setJobs(prev => [...prev, ...list]);
  };

  const clearAll = () => { if (!isRunning) setJobs([]); };
  const cancelAll = () => {
    abortRef.current?.abort();
    setIsRunning(false);
    setJobs(prev => prev.map(j => (j.status==="running"||j.status==="queued") ? {...j, status:"canceled"} : j));
  };

  const visibleJobs = useMemo(() => {
    if (filter==="all") return jobs;
    return jobs.filter(j => j.status===filter);
  }, [jobs, filter]);

  const start = async () => {
    if (!apiUrl || !jobs.length) return;
    setIsRunning(true);
    const ac = new AbortController(); abortRef.current = ac;

    let queue = jobs.map(j => (j.status==="done" ? j : {...j, status:"queued"}));
    setJobs(queue);

    let inFlight = 0, cursor = 0;

    const update = (id: string, patch: Partial<Job>) =>
      setJobs(prev => prev.map(j => j.id === id ? {...j, ...patch} : j));

    const runOne = async (job: Job) => {
      inFlight++;
      const startedAt = performance.now();
      update(job.id, { status:"running", startedAt });
      try {
        const result = await predictOne(apiUrl, job.file, ac.signal);
        const finishedAt = performance.now();
        update(job.id, { status:"done", finishedAt, ms: Math.round(finishedAt - startedAt), result });
      } catch (e:any) {
        const finishedAt = performance.now();
        update(job.id, { status: ac.signal.aborted ? "canceled":"error", finishedAt, ms: Math.round(finishedAt - startedAt), error: String(e?.message||e) });
      } finally {
        inFlight--; pump();
      }
    };

    const pump = () => {
      if (ac.signal.aborted) return;
      while (inFlight < concurrency && cursor < queue.length) {
        const job = queue[cursor++]; if (!job || job.status!=="queued") continue;
        void runOne(job);
      }
      if (cursor >= queue.length && inFlight === 0) {
        setIsRunning(false);
        abortRef.current = null;
      }
    };

    pump();
  };

  const downloadCSV = () => {
    const rows = jobs.filter(j=>j.status==="done" && j.result).map(j => ({
      file: j.name,
      top1_label: j.result!.top1.label,
      top1_prob: j.result!.top1.prob,
      all_labels: j.result!.labels_current.join("|"),
      all_probs: j.result!.probs.map(p => p.toFixed(6)).join("|"),
      time_ms: j.ms ?? "",
    }));
    const csv = toCSV(rows);
    const blob = new Blob([csv], { type:"text/csv;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a"); a.href = url; a.download = "results.csv"; a.click();
    URL.revokeObjectURL(url);
  };

  const running = jobs.filter(j=>j.status==="running").length;
  const done = jobs.filter(j=>j.status==="done").length;
  const error = jobs.filter(j=>j.status==="error").length;

  return (
    <div className="w-full max-w-6xl mx-auto">
      <section className="text-center space-y-3 mb-8">
        <h1 className="text-3xl md:text-4xl font-bold">Batch Analysis</h1>
        <p className="text-gray-600 max-w-2xl mx-auto">
          อัปโหลดหลายภาพทีเดียว ปรับจำนวนงานพร้อมกันได้ เพื่อวิเคราะห์เร็วขึ้นบน API เดิม
        </p>
      </section>

      <div className="grid md:grid-cols-2 gap-6">
        {/* ซ้าย */}
        <div className="rounded-2xl border p-4 md:p-5 bg-white">
          <div>
            <label className="block text-sm font-medium mb-1">เลือกรูปภาพ</label>
            <input type="file" accept="image/*" multiple onChange={(e)=>onPickFiles(e.target.files)} />
          </div>

          <div className="mt-3 border-2 border-dashed rounded-xl p-6 text-center text-gray-500 hover:border-gray-400 transition-colors"
               onDrop={(e)=>{e.preventDefault();onPickFiles(e.dataTransfer?.files ?? null);}}
               onDragOver={(e)=>{e.preventDefault();}}>
            ลาก & วาง รูปภาพลงที่นี่
          </div>

          <div className="mt-4">
            <label className="block text-sm font-medium mb-1">Concurrency: <b>{concurrency}</b></label>
            <input type="range" min={1} max={8} value={concurrency}
                   onChange={(e)=>setConcurrency(parseInt(e.target.value,10))}
                   className="w-full" />
            <p className="text-xs text-gray-500 mt-1">
              แนะนำ 2–4 ถ้า API อยู่บนเครื่องหรือ ngrok; ค่อย ๆ เพิ่มถ้าระบบรองรับ
            </p>
          </div>

          <div className="mt-4 flex flex-wrap gap-2">
            {!isRunning ? (
              <button onClick={start}
                      disabled={!jobs.some(j=>["queued","error","canceled"].includes(j.status))}
                      className="px-4 py-2 rounded-lg bg-black text-white disabled:opacity-50">
                เริ่มวิเคราะห์
              </button>
            ) : (
              <button onClick={cancelAll} className="px-4 py-2 rounded-lg bg-red-600 text-white">
                ยกเลิกทั้งหมด
              </button>
            )}
            <button onClick={clearAll} disabled={isRunning || jobs.length===0}
                    className="px-4 py-2 rounded-lg border disabled:opacity-50">
              ล้างรายการ
            </button>
            <button onClick={downloadCSV} disabled={done===0}
                    className="px-4 py-2 rounded-lg border disabled:opacity-50">
              ดาวน์โหลด CSV
            </button>
          </div>

          <div className="mt-3 text-sm text-gray-600">
            รวม: {jobs.length} | กำลังรัน: {running} | เสร็จ: {done} | error: {error}
          </div>

          {jobs.length>0 && (
            <div className="mt-4 grid grid-cols-3 gap-2">
              {jobs.slice(0,6).map(j=>(
                <div key={j.id} className="aspect-square bg-gray-50 border rounded-lg overflow-hidden">
                  {j.preview ? <img src={j.preview} alt={j.name} className="w-full h-full object-cover" /> :
                    <div className="w-full h-full grid place-items-center text-xs text-gray-400">preview</div>}
                </div>
              ))}
            </div>
          )}
        </div>

        {/* ขวา */}
        <div className="rounded-2xl border p-4 md:p-5 bg-white">
          <div className="flex items-center justify-between mb-3">
            <div className="text-sm font-medium">ผลลัพธ์</div>
            <div className="flex gap-2">
              {(["all","queued","running","done","error"] as const).map(k=>(
                <button key={k} onClick={()=>setFilter(k)}
                        className={`px-3 py-1 rounded-lg border text-xs ${filter===k?"bg-black text-white":"bg-white"}`}>
                  {k}
                </button>
              ))}
            </div>
          </div>

          <div className="space-y-3 max-h-[520px] overflow-auto pr-1">
            {visibleJobs.map(j=>(
              <div key={j.id} className="border rounded-xl p-3">
                <div className="flex items-center gap-3">
                  <div className="w-14 h-14 bg-gray-50 rounded-lg overflow-hidden shrink-0">
                    {j.preview ? <img src={j.preview} className="w-full h-full object-cover" /> : null}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="font-medium truncate">{j.name}</div>
                    <div className="text-xs text-gray-500">เวลา: {fmtMs(j.ms)}</div>
                  </div>
                  <div className={`text-xs px-2 py-1 rounded-full shrink-0
                    ${j.status==="done"?"bg-emerald-100 text-emerald-700":
                      j.status==="running"?"bg-blue-100 text-blue-700":
                      j.status==="error"?"bg-red-100 text-red-700":
                      j.status==="canceled"?"bg-gray-200 text-gray-700":"bg-gray-100 text-gray-700"}`}>
                    {j.status}
                  </div>
                </div>

                {j.result && (
                  <div className="mt-2 text-sm">
                    <div>Top‑1: <b>{j.result.top1.label}</b> ({j.result.top1.prob.toFixed(6)})</div>
                    <div className="mt-1 flex flex-wrap gap-x-3 gap-y-1 text-xs">
                      {j.result.predictions.map((p,i)=>(
                        <span key={i} className="inline-flex items-center gap-1">
                          <span className="inline-block w-1.5 h-1.5 rounded-full bg-gray-400" />
                          {p.label}: {p.prob.toFixed(4)}
                        </span>
                      ))}
                    </div>
                  </div>
                )}

                {j.error && <div className="text-xs text-red-600 mt-1 break-all">{j.error}</div>}
              </div>
            ))}
            {visibleJobs.length===0 && (<div className="text-sm text-gray-500">ยังไม่มีรายการ</div>)}
          </div>
        </div>
      </div>
    </div>
  );
}
